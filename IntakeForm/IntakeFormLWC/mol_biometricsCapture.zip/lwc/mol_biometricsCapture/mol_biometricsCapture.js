import { LightningElement, track, api } from 'lwc';
import savePhotoFile from '@salesforce/apex/PhotoCaptureController.savePhotoFile';
import getExistingPhoto from '@salesforce/apex/PhotoCaptureController.getExistingPhoto';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

export default class Mol_biometricsCapture extends LightningElement {
    @api contactId;
    @track capturedImage;
    @track showCapturedImage = true;
    @track showOpenCamera = true;
    @track showTakePhoto = false;
    @track showRetake = false;
    @track isExistingPhoto = false;
    videoStream;

    connectedCallback() {
        this.checkIfPhotoExists();
    }
    // handleButtonClick() {
    //     this.refs.target.handleRefresh();
    // }
    async checkIfPhotoExists() {
        if (!this.contactId) return;

        try {
            const existingPhotoId = await getExistingPhoto({
                contactId: this.contactId,
                fileInitial: 'Biometric%'
            });

            if (existingPhotoId) {
                const photoUrl = `/sfc/servlet.shepherd/version/download/${existingPhotoId}`;
                this.capturedImage = photoUrl;
                this.showCapturedImage = false;
                this.showOpenCamera = false;
                this.showRetake = true;
                this.isExistingPhoto = true;
            }

        } catch (error) {
            console.error('Error fetching existing photo: ', error);
        }
    }

    startCamera() {
        this.showCapturedImage = true;
        this.showOpenCamera = false;
        this.showTakePhoto = true;
        this.showRetake = false;

        const video = this.template.querySelector('video');

        if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
            navigator.mediaDevices.getUserMedia({ video: true })
                .then(stream => {
                    this.videoStream = stream;
                    video.srcObject = stream;
                })
                .catch(error => {
                    console.error('Error accessing camera:', error);
                });
        }
    }

    capturePhoto() {
        this.showCapturedImage = false;
        this.showTakePhoto = false;
        this.showRetake = true;
        this.isExistingPhoto = false;

        const video = this.template.querySelector('video');
        const canvas = this.template.querySelector('canvas');
        const context = canvas.getContext('2d');

        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        context.drawImage(video, 0, 0, canvas.width, canvas.height);

        this.capturedImage = canvas.toDataURL('image/jpeg');

        if (this.videoStream) {
            this.videoStream.getTracks().forEach(track => track.stop());
        }
    }

    handleRetake() {
        this.showCapturedImage = true;
        this.showRetake = false;
        this.showTakePhoto = true;
        this.isExistingPhoto = false;

        setTimeout(() => {
            this.startCamera();
        }, 0);
    }

    handleUploadClick() {
        const fileInput = this.template.querySelector('.file-input');
        fileInput.click();
    }

    handleFileSelected(event) {
        const file = event.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onloadend = () => {
            this.capturedImage = reader.result;
            this.showCapturedImage = false;
            this.showTakePhoto = false;
            this.showOpenCamera = false;
            this.showRetake = true;
            this.isExistingPhoto = false;
        };
        reader.readAsDataURL(file);
    }

    async handleSave() {
        if (!this.contactId) {
            this.showToast('Error', 'Contact ID is missing. Please complete the previous step.', 'error');
            return;
        }

        if (this.isExistingPhoto) {
            this.dispatchEvent(new CustomEvent('biometriccompleted', { bubbles: true, composed: true }));
            return;
        }

        try {
            const base64String = this.capturedImage?.split(',')[1];
            if (!base64String) {
                this.showToast('Error', 'No photo to upload. Please take or select a photo.', 'error');
                return;
            }

            await savePhotoFile({
                base64Data: base64String,
                fileName: 'Biometric_' + new Date().getTime() + '.jpg',
                contactId: this.contactId
            });

            this.showToast('Success', 'Photo saved successfully', 'success');
            //  this.refs.target.handleRefresh();
            this.dispatchEvent(new CustomEvent('biometriccompleted', { bubbles: true, composed: true }));
           

        } catch (error) {
            this.showToast('Error', 'Photo saving failed: ' + (error.body?.message || error.message), 'error');
            console.error('Save photo error:', error);
        }
    }

    disconnectedCallback() {
        if (this.videoStream) {
            this.videoStream.getTracks().forEach(track => track.stop());
        }
    }

    showToast(title, message, variant) {
        this.dispatchEvent(new ShowToastEvent({
            title,
            message,
            variant
        }));
    }

    handleBack() {
        this.dispatchEvent(new CustomEvent('biometriback', {
            detail: { contactId: this.contactId },
            bubbles: true,
            composed: true
        }));
    }
}