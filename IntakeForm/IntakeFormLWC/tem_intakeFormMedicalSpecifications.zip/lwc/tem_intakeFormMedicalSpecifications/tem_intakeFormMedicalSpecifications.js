import { LightningElement, track, api } from 'lwc';
import tem_CBP_formicons from '@salesforce/resourceUrl/tem_CBP_formicons';
import saveTravelConsideration from '@salesforce/apex/IntakeFormUplaodDocument.saveTravelConsideration';
import getPicklistValues from '@salesforce/apex/IntakeFormController.getPicklistValues';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

export default class Tem_intakeFormMedicalSpecifications extends LightningElement {

    dropdown = tem_CBP_formicons + '/icon_dropdown.svg';
    @api selectedContactId;
    // @track selectedContactId = '003cq00000DxrNNAAZ';
    @track mediCondiPrevintingflightOptions = [];
    @track physicalAssistanceOptions = [];
    @track mobilityIssuesOptions = [];
    @track medicalEquipmentOptions = [];
    @track pregnancyStatusOptions = [];
    @track recentMedicalEventsOptions = [];
    @track petServiceOptions = [];
    @track seatingRequirementsOptions = [];
    @track dietaryRestrictionsOptions = [];

    @track selectedFlyValue;
    @track selectedAssistance;
    @track selectedMobilityIssueValue;
    @track medicalEquipment;
    @track preganancyStatus;
    @track recentMedicalEvents;
    @track selectedPetServiceValue;
    @track seatingRequirementsValues;
    @track foodPreferenceValues;
    @track additionalNotes = '';

    @track selectedFoodValues = [];
    @track selectedEquipmentValues = [];

    connectedCallback() {
        console.log('this.selectedContactId', JSON.stringify(this.selectedContactId));
        this.fetchPicklistValues('Travel_Consideration__c', 'Medical_Condition_Preventing_Flight__c', 'mediCondiPrevintingflightOptions');
        this.fetchPicklistValues('Travel_Consideration__c', 'Physical_Translation_Assistance_Required__c', 'physicalAssistanceOptions');
        this.fetchPicklistValues('Travel_Consideration__c', 'Mobility_Issues__c', 'mobilityIssuesOptions');
        this.fetchPicklistValues('Travel_Consideration__c', 'Medical_Equipment_Required__c', 'medicalEquipmentOptions');
        this.fetchPicklistValues('Travel_Consideration__c', 'Pregnancy_Status__c', 'pregnancyStatusOptions');
        this.fetchPicklistValues('Travel_Consideration__c', 'Recent_Medical_Events__c', 'recentMedicalEventsOptions');
        this.fetchPicklistValues('Travel_Consideration__c', 'Pet_Service_Animal_Travel__c', 'petServiceOptions');
        this.fetchPicklistValues('Travel_Consideration__c', 'Special_Seating_Requirements__c', 'seatingRequirementsOptions');
        this.fetchPicklistValues('Travel_Consideration__c', 'Dietary_Restrictions__c', 'dietaryRestrictionsOptions');
    }

    fetchPicklistValues(objectApiName, fieldApiName, stateProperty) {
        getPicklistValues({ objectApiName, fieldApiName })
            .then(data => {
                this[stateProperty] = data.map(item => ({
                    label: item.label,
                    value: item.value
                }));
                // Only add "None" option for single-select fields that don't already have it
                // Don't add "None" for multi-select fields like Medical Equipment and Dietary Restrictions
                if (stateProperty !== 'medicalEquipmentOptions' && 
                    stateProperty !== 'dietaryRestrictionsOptions' && 
                    !this[stateProperty].some(opt => opt.value === 'None')) {
                    this[stateProperty].unshift({ label: 'None', value: 'None' });
                }
            })
            .catch(error => {
                this.showToast('Error', `Error fetching ${fieldApiName} values`, 'error');
            });
    }

    showToast(title, message, variant) {
        this.dispatchEvent(
            new ShowToastEvent({
                title: title,
                message: message,
                variant: variant
            })
        );
    }

    // Handler methods
    handleFlyChange(event) {
        this.selectedFlyValue = event.detail.value;
        console.log('this.selectedFlyValue', JSON.stringify(this.selectedFlyValue));
    }

    handleAssistanceChange(event) {
        this.selectedAssistance = event.detail.value;
        console.log('this.selectedAssistance', JSON.stringify(this.selectedAssistance));
    }

    handleMobilityIssueChange(event) {
        this.selectedMobilityIssueValue = event.detail.value;
        console.log('this.selectedMobilityIssueValue', JSON.stringify(this.selectedMobilityIssueValue));
    }

    handleMedicalEquipmentIssueChange(event) {
        this.medicalEquipment = event.detail.value;
        console.log('this.medicalEquipment', JSON.stringify(this.medicalEquipment));
    }

    handlePregancyStatusChange(event) {
        this.preganancyStatus = event.detail.value;
        console.log('this.preganancyStatus', JSON.stringify(this.preganancyStatus));
    }

    handleRecentMedicalEventsChange(event) {
        this.recentMedicalEvents = event.detail.value;
        console.log('this.recentMedicalEvents', JSON.stringify(this.recentMedicalEvents));
    }

    handlePetService(event) {
        this.selectedPetServiceValue = event.detail.value;
        console.log('this.selectedPetServiceValue', JSON.stringify(this.selectedPetServiceValue));
    }

    handleseatingRequirementsValues(event) {
        this.seatingRequirementsValues = event.detail.value;
        console.log('this.seatingRequirementsValues', JSON.stringify(this.seatingRequirementsValues));
    }

    handlefoodPreferenceValuesChange(event) {
        this.foodPreferenceValues = event.detail.value;
        console.log('this.foodPreferenceValues', JSON.stringify(this.foodPreferenceValues));
    }

    handleTextareaChange(event) {
        this.additionalNotes = event.target.value;
        console.log('this.additionalNotes', JSON.stringify(this.additionalNotes));
    }

     handleSave() {
        const dietaryValuesOnly = this.selectedFoodValues.map(item => item.value);
        const equipmentsValuesOnly = this.selectedEquipmentValues.map(item => item.value);

        // Filter out "None" values and empty arrays
        const filteredDietaryValues = dietaryValuesOnly.filter(val => val && val !== 'None');
        const filteredEquipmentValues = equipmentsValuesOnly.filter(val => val && val !== 'None');

        saveTravelConsideration({
            medicalCondition: this.selectedFlyValue === 'None' ? null : this.selectedFlyValue,
            physicalAssistance: this.selectedAssistance === 'None' ? null : this.selectedAssistance,
            mobilityIssues: this.selectedMobilityIssueValue === 'None' ? null : this.selectedMobilityIssueValue,
            medicalEquipment: filteredEquipmentValues.length > 0 ? filteredEquipmentValues : null,
            pregnancyStatus: this.preganancyStatus === 'None' ? null : this.preganancyStatus,
            recentMedicalEvents: this.recentMedicalEvents === 'None' ? null : this.recentMedicalEvents,
            petService: this.selectedPetServiceValue === 'None' ? null : this.selectedPetServiceValue,
            seatingRequirements: this.seatingRequirementsValues === 'None' ? null : this.seatingRequirementsValues,
            dietaryRestrictions: filteredDietaryValues.length > 0 ? filteredDietaryValues : null,
            additionalNotes: this.additionalNotes,
            contactId: this.selectedContactId
        })
        .then(() => {
            this.showToast('Success', 'Travel consideration saved successfully', 'success');
            this.dispatchEvent(new CustomEvent('medicalformcompleted', { bubbles: true, composed: true }));
            this.resetForm();
        })
        .catch(error => {
            this.showToast('Error', error.body.message, 'error');
        });
    }

    resetForm() {
        this.selectedFlyValue = null;
        this.selectedAssistance = null;
        this.selectedMobilityIssueValue = null;
        this.medicalEquipment = null;
        this.preganancyStatus = null;
        this.recentMedicalEvents = null;
        this.selectedPetServiceValue = null;
        this.seatingRequirementsValues = null;
        this.foodPreferenceValues = null;
        this.additionalNotes = '';
    }

    handleBack() {
        this.dispatchEvent(new CustomEvent(
            'backclicked',
            { bubbles: true, composed: true }
        ));
    }


    handleNext() {
        this.dispatchEvent(new CustomEvent(
            'aftermedicalcomplete',
            { bubbles: true, composed: true }
        ));
    }

    @track tempFoodSelections = new Map();
    @track tempEquipmentSelections = new Map();
    @track isOpen = false;
    @track isEquipmentOpen = false;

    toggleDropdown(event) {
        event.stopPropagation();
        this.isOpen = !this.isOpen;
        if (this.isOpen) {
            // Sync temp selections with current selected state
            this.dietaryRestrictionsOptions.forEach(opt => {
                const isSelected = this.selectedFoodValues.some(sel => sel.value === opt.value);
                this.tempFoodSelections.set(opt.value, isSelected);
                opt.selected = isSelected;
            });
            // Force re-render
            this.dietaryRestrictionsOptions = [...this.dietaryRestrictionsOptions];
        }
    }

    handleDropdownClick(event) {
        event.stopPropagation();
    }

    handleFoodCheckboxChange(event) {
        event.stopPropagation();
        const foodId = event.target.dataset.id;
        const isChecked = event.target.checked;

        this.tempFoodSelections.set(foodId, isChecked);

        // Update the project options to reflect the change
        this.dietaryRestrictionsOptions = this.dietaryRestrictionsOptions.map(option => ({
            ...option,
            selected: option.value === foodId ? isChecked : option.selected
        }));
    }

    get firstSelectedFood() {
        return this.selectedFoodValues.length > 0 ? this.selectedFoodValues[0] : null;
    }

    get hasExtraSelections() {
        return this.selectedFoodValues.length > 1;
    }

    get extraSelectionCount() {
        return this.selectedFoodValues.length - 1;
    }


    applyFoodSelection(event) {
        event.stopPropagation();
        this.selectedFoodValues = [];

        // Build selected projects from temp selections
        this.dietaryRestrictionsOptions.forEach(option => {
            if (this.tempFoodSelections.get(option.value)) {
                this.selectedFoodValues.push({
                    label: option.label,
                    value: option.value
                });
            }
        });

        this.isOpen = false;
    }

    removeSelectedFood(event) {
        const valueToRemove = event.currentTarget.dataset.value;
        this.selectedFoodValues = this.selectedFoodValues.filter(p => p.value !== valueToRemove);

        // Update temp selections and project options
        this.tempFoodSelections.set(valueToRemove, false);
        this.dietaryRestrictionsOptions = this.dietaryRestrictionsOptions.map(opt => ({
            ...opt,
            selected: opt.value === valueToRemove ? false : opt.selected
        }));
    }


    // seating dropwn
    toggleEquipmentDropdown(event) {
        event.stopPropagation();
        this.isEquipmentOpen = !this.isEquipmentOpen;
        if (this.isEquipmentOpen) {

            this.medicalEquipmentOptions.forEach(opt => {
                const isSelected = this.selectedEquipmentValues.some(sel => sel.value === opt.value);
                this.tempEquipmentSelections.set(opt.value, isSelected);
                opt.selected = isSelected;
            });

            this.medicalEquipmentOptions = [...this.medicalEquipmentOptions];
        }
    }

    handleEquipmentCheckboxChange(event) {
        event.stopPropagation();
        const equipmentId = event.target.dataset.id;
        const isChecked = event.target.checked;

        this.tempEquipmentSelections.set(equipmentId, isChecked);

        this.medicalEquipmentOptions = this.medicalEquipmentOptions.map(option => ({
            ...option,
            selected: option.value === equipmentId ? isChecked : option.selected
        }));
    }

    get firstSelectedEquipment() {
        return this.selectedEquipmentValues.length > 0 ? this.selectedEquipmentValues[0] : null;
    }

    get hasExtraEquipmentSelections() {
        return this.selectedEquipmentValues.length > 1;
    }

    get extraEquipmentSelectionCount() {
        return this.selectedEquipmentValues.length - 1;
    }


    applyEquipmentSelection(event) {
        event.stopPropagation();
        this.selectedEquipmentValues = [];

        this.medicalEquipmentOptions.forEach(option => {
            if (this.tempEquipmentSelections.get(option.value)) {
                this.selectedEquipmentValues.push({
                    label: option.label,
                    value: option.value
                });
            }
        });

        this.isEquipmentOpen = false;
    }

    removeSelectedEquip(event) {
        const valueToRemove = event.currentTarget.dataset.value;
        this.selectedEquipmentValues = this.selectedEquipmentValues.filter(p => p.value !== valueToRemove);
        this.tempEquipmentSelections.set(valueToRemove, false);
        this.medicalEquipmentOptions = this.medicalEquipmentOptions.map(opt => ({
            ...opt,
            selected: opt.value === valueToRemove ? false : opt.selected
        }));
    }

}