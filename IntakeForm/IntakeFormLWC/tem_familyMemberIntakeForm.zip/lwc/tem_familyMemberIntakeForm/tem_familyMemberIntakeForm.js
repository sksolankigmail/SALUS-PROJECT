import { LightningElement, track, api } from 'lwc';
import getPicklistValues from '@salesforce/apex/IntakeFormController.getPicklistValues';
import saveContact from '@salesforce/apex/IntakeFormController.saveContact';
import tem_CBP_formicons from '@salesforce/resourceUrl/tem_CBP_formicons';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';


export default class Tem_familyMemberIntakeForm extends LightningElement {

    forwardArrow = tem_CBP_formicons + '/icon_right_arrow.svg';
    first_icon = tem_CBP_formicons + '/first_icon.svg';
    icon_deselect_1 = tem_CBP_formicons + '/icon_deselect_1.svg';
    second_icon = tem_CBP_formicons + '/second_icon.svg';
    deselect_second = tem_CBP_formicons + '/deselect_second.svg';
    icon_checked = tem_CBP_formicons + '/icon_checked.svg';

    @api accountId = '';
    @track fields = {
        firstName: '',
        lastName: '',
        email: '',
        phone: '',
        gender: '',
        birthdate: '',
        relationship: ''
    };

    @track generatedFamilyContactId;
    @track currentStep = 'personal';

    @track isPersonalCompleted = false;
    @track isBiometricCompleted = false;

    @track personalDetails = true;
    @track showBiometrics = false;
    @track showSuccess = true;

    @track selectedGender;
    @track genderOptions = [];

    @track selectedRelationship;
    @track relationshipOptions= [];

    get personalTabClass() {
        if (this.currentStep === 'personal') return 'active-tab';
        return this.isPersonalCompleted ? 'completed-tab' : 'pending-tab';
    }

    get biometricsTabClass() {
        if (this.currentStep === 'biometrics') return 'active-tab';
        return this.isBiometricCompleted ? 'completed-tab' : 'pending-tab';
    }

    get isCurrentStepPersonal() {
        return this.currentStep === 'personal';
    }

    get isCurrentStepBiometric() {
        return this.currentStep === 'biometrics';
    }

    handleGenderChange(event) {
        this.selectedGender = event.detail.value;
        console.log('Selected gender:', this.selectedGender);
    }

    handleRelationshipChange(event){
        this.selectedRelationship = event.detail.value;
        console.log('Seelected Relationship', this.selectedRelationship);
    }

    handleBack() {
        this.medicalDetails = false;
        this.personalDetails = true;
        this.showBiometrics = false;
    }

    handleNext() {
        this.showBiometrics = true;
        this.personalDetails = false;
        this.isPersonalCompleted = true;
        this.currentStep = 'biometrics';
    }

    get formattedBirthdate() {
        if (!this.fields.birthdate) return '';
        const date = new Date(this.fields.birthdate);
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        const year = date.getFullYear();
        return `${month}/${day}/${year}`;
    }

    handleChange(event) {
        const field = event.target.dataset.field || event.target.name;
        const value = event.target.value;

        let finalValue = value;

        // If it's a date field in MM/DD/YYYY format, convert to ISO (YYYY-MM-DD)
        if (event.target.type === 'text' && field === 'birthdate') {
            const parts = value.split('/');
            if (parts.length === 3) {
                const [month, day, year] = parts;
                if (month.length === 2 && day.length === 2 && year.length === 4) {
                    finalValue = `${year}-${month}-${day}`;
                }
            }
        }

        this.fields[field] = finalValue;
        console.log(`Field ${field} updated: ${finalValue}`);
    }

    connectedCallback() {
        this.fetchPicklistValues('Contact', 'Gender__c', 'genderOptions');
        this.fetchPicklistValues('Contact', 'Relationship_with_Primary_Contact__c', 'relationshipOptions');
    }

    fetchPicklistValues(objectApiName, fieldApiName, stateProperty) {
        getPicklistValues({ objectApiName, fieldApiName })
            .then(data => {
                this[stateProperty] = data.map(item => ({
                    label: item.label,
                    value: item.value
                }));
                console.log(`${fieldApiName} Picklist Values:`, this[stateProperty]);
            })
            .catch(error => {
                this.showToast('Error', `Error fetching ${fieldApiName} values`, 'error');
            });
    }


    async handleSaveAndNext() {
        try {
            // Call the save method
            await this.handleSave();

        } catch (error) {
            console.error('Save failed:', error);
            this.showToast('Error', 'Please Fill all the mandatory details.', 'error');
        }
    }

    async handleSave() {
        const contactData = {
            firstName: this.fields.firstName,
            lastName: this.fields.lastName,
            birthdate: this.fields.birthdate,
            gender: this.selectedGender,
            accountId: this.accountId,
            email: this.fields.email,
            phone: this.fields.phone,
            relationship: this.selectedRelationship
        };
        this.primaryMember = this.fields.firstName;
        console.log('this.memberCount', JSON.stringify(this.memberCount));

        try {
            const contactId = await saveContact({ contactData });
            this.showToast('Success', 'Contact saved successfully!', 'success');
            this.generatedFamilyContactId = contactId.Id;
            this.personalDetails = false;
            this.isPersonalCompleted = true;
            this.currentStep = 'biometrics';
            this.showBiometrics = true;
            console.log('Saved Contact ID:', contactId);
        } catch (error) {
            console.error('Error saving contact:', error);

            if (error.body && error.body.message && error.body.message.includes('DUPLICATES_DETECTED')) {
                // Try guessing the field
                let possibleFields = [];
                if (this.fields.email) possibleFields.push('Email');
                if (this.fields.phone) possibleFields.push('Phone');
                if (this.fields.whatsapp) possibleFields.push('WhatsApp');
                if (this.fields.passportNumber) possibleFields.push('Passport Number');

                this.showToast(
                    'Duplicate Record',
                    `A contact with similar ${possibleFields.join(', ')} may already exist.`,
                    'warning'
                );
            } else {
                this.showToast('Error', 'Failed to save contact.', 'error');
            }
        }

    }

    showToast(title, message, variant) {
        this.dispatchEvent(
            new ShowToastEvent({
                title: title,
                message: message,
                variant: variant
            })
        );
    }

    handleBiometriBack() {
        this.personalDetails = true;
        this.showBiometrics = false;
    }

    @api currentMemberIndex;
    handleBiometricCompleted() {
        this.showSuccess = true;
        this.showBiometrics = false;
        this.isBiometricCompleted = true;
        console.log('this.currentIndex', JSON.stringify(this.currentMemberIndex));
        const event = new CustomEvent('familycompleted', {
            detail: {
                memberIndex: this.currentMemberIndex 
            },
            bubbles: true,
            composed: true
        });
        this.dispatchEvent(event);
        const event1 = new CustomEvent('biometricscompleted', {
            detail: {
                memberIndex: this.currentMemberIndex 
            },
            bubbles: true,
            composed: true
        });
        this.dispatchEvent(event1);
    }
}