import { LightningElement, api, track } from 'lwc';
import tem_CBP_formicons from '@salesforce/resourceUrl/tem_CBP_formicons';

export default class Tem_customDropdown extends LightningElement {

    dropdown = tem_CBP_formicons + '/icon_dropdown.svg';
    @api options = [];
    @api value;
    @api placeholder = 'Select...';
    @api name = '';
    @api fieldName = '';

    @track isOpen = false;
 boundCloseDropdown;

    get selectedLabel() {
        if (!this.options || !Array.isArray(this.options)) return this.placeholder;

        const selected = this.options.find(opt => opt.value === this.value);
        return selected ? selected.label : this.placeholder;
    }


    toggleDropdown(event) {
        event.stopPropagation();
        this.isOpen = !this.isOpen;
    }

    handleSelect(event) {
          event.stopPropagation();
        event.preventDefault();
        const selectedValue = event.currentTarget.dataset.value;
        this.value = selectedValue;
        this.isOpen = false;

        // Dispatch a 'change' event like native components
        this.dispatchEvent(new CustomEvent('change', {
            detail: {
                value: selectedValue,
                name: this.name,
                fieldName: this.fieldName
            },
            bubbles: true,
            composed: true
        }));
    }

    // Optional: close dropdown on outside click
    connectedCallback() {
        this.boundCloseDropdown = this.closeDropdown.bind(this);
         document.addEventListener('click', this.closeDropdown.bind(this));
    }

        disconnectedCallback() {
        document.removeEventListener('click', this.closeDropdown.bind(this));
    }



    closeDropdown() {
        
        this.isOpen = false;
    }

}