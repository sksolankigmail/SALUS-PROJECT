import { LightningElement } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import tem_CBP_formicons from '@salesforce/resourceUrl/tem_CBP_formicons';

export default class Tem_cbpSalusHome extends NavigationMixin(LightningElement)  {

    // banner = tem_CBP_formicons + '/cbpBanner.jpg';
    banner1 = tem_CBP_formicons + '/bannerImg.jpeg';

    handleButtonClick(event) {
        const menuItem = event.currentTarget.dataset.id;

        if (menuItem === 'cbp-form') {
            this[NavigationMixin.Navigate]({
                type: 'comm__namedPage',
                attributes: {
                    name: 'CBP_Form__c'
                }
            });
        }
    }
}