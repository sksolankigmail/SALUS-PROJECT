import { LightningElement, api, wire, track } from 'lwc';
import getContactrecords from '@salesforce/apex/IntakeFormUplaodDocument.getContactrecords';
import {refreshApex} from '@salesforce/apex';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

export default class Tem_memberFormListview extends LightningElement {

    @api selectedContactId;
    @api selectedAccountId;
    @api primaryMember;
    @track contacts = [];
    @track wiredContactResult;

    handleMoreMember() {
        this.dispatchEvent(new CustomEvent('addmemberuploaded', {
            bubbles: true,
            composed: true
        }));
    }

    handleSaveAndNext() {
        this.dispatchEvent(new CustomEvent('afteraddmember', {
            bubbles: true,
            composed: true
        }));
    }

    @wire(getContactrecords, { accountId: '$selectedAccountId' })
    wiredgetContacts(result) {
        this.wiredContactResult = result;
        const { error, data } = result;
        if (data) {
            try {
                console.log('account data:', JSON.stringify(data, null, 2));
                if (Array.isArray(data)) {
                    this.contacts = data.map(acc => {
                        return {
                            Id: acc?.Id || '',
                            Name: acc?.Name || '',
                            Email: acc?.Email || '-',
                            Phone: acc?.Phone || '-',
                            IsPrimary: acc.Is_Primary_Contact__c ? 'Primary Contact' : 'Travel Companion',
                            Relationship: acc?.Relationship_with_Primary_Contact__c || 'Primary'
                        };
                    });
                }
                console.log('after storing', JSON.stringify(this.contacts, null, 2));
            } catch (e) {
                console.error('Error:', e);
            }
        } else if (error) {
            console.error('Error fetching leave requests:', error);
        }
    }

  
    handleMedicalInfo() {
        this.dispatchEvent(new CustomEvent('medicalinfo', {
            bubbles: true,
            composed: true
        }));
    }

    @api handleRefresh() {
        console.log('handleRefresh called in child component');
        refreshApex(this.wiredContactResult);
        // this.showToast('success', 'Member(s) Details are refreshed.', 'success');
    }

    showToast(title, message, variant) {
        this.dispatchEvent(
            new ShowToastEvent({
                title: title,
                message: message,
                variant: variant
            })
        );
    }

}