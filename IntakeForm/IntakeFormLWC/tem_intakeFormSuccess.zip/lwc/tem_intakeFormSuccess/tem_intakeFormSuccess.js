import { LightningElement, api, track } from 'lwc';
import tem_CBP_formicons from '@salesforce/resourceUrl/tem_CBP_formicons';

export default class Tem_intakeFormSuccess extends LightningElement {


  successIcon = tem_CBP_formicons + '/success_icon.png';
  rightIcon = tem_CBP_formicons + '/right_circle_arrow_icon.svg';
  checked = tem_CBP_formicons + '/icon_checked.svg';

  @track memberButtons = [];
  @api addedMembers = [];


  _memberCount;
  @api
  get memberCount() {
    return this._memberCount;
  }

  set memberCount(value) {
    this._memberCount = parseInt(value, 10);
    if (this._memberCount > 0) {
      this.generateMemberButtons();
    }
  }

  @api primary;

  @api
  markMemberAsAdded(index) {
    this.generateMemberButtons();
  }

  generateMemberButtons() {
    const buttons = [];
    for (let i = 1; i < this._memberCount; i++) {
      buttons.push({
        label: `Add Member ${i}`,
        id: i,
        isAdded: this.addedMembers.includes(i)
      });
    }
    this.memberButtons = buttons;
  }

  handleAddMember(event) {
    const index = parseInt(event.currentTarget.dataset.id, 10);
    if (this.addedMembers.includes(index)) return;

    this.dispatchEvent(new CustomEvent('familymemberclicked', {
      detail: { memberIndex: index },
      bubbles: true,
      composed: true
    }));
  }

  get allMembersAdded() {
    if (!this.memberButtons.length) return false;
    return this.memberButtons.every(member => member.isAdded);
  }

}