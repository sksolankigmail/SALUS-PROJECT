import { LightningElement, track, api } from 'lwc';
import uploadFileToRecord from '@salesforce/apex/IntakeFormUplaodDocument.uploadFileToRecord';
import tem_CBP_formicons from '@salesforce/resourceUrl/tem_CBP_formicons';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

export default class Tem_uploadDocument extends LightningElement {
    upload = tem_CBP_formicons + '/cloudUpload.svg';

    @track idFields = [
        { key: 'identification', currentFileName: '', uploaded: false }
    ];

    fileDetailsId = {
        contents: {},
        types: {},
        titles: {}
    };

    @api selectedContactId;
    @track isNoDocumentChecked = false;

    handleNoDocsCheckboxChange(event) {
        this.isNoDocumentChecked = event.target.checked;
        if (this.isNoDocumentChecked) {
            this.removeAllAttachments();
        }
    }

    get hasUploadedFiles() {
        return this.idFields.some(field => field.currentFileName !== '');
    }

    triggerFilePicker(event) {
        const fieldKey = event.target.dataset.id;
        const input = this.template.querySelector(`input[data-id="${fieldKey}"]`);
        if (input) input.click();
    }

    handleIdDocumentChange(event) {
        const fieldKey = event.target.dataset.id;
        const file = event.target.files[0];
        if (!file) return;

        if (file.size > 2 * 1024 * 1024) {
            this.showError('File size exceeds 2MB.');
            return;
        }

        const reader = new FileReader();
        reader.onload = () => {
            const base64 = reader.result.split(',')[1];
            this.fileDetailsId.contents[fieldKey] = base64;
            this.fileDetailsId.types[fieldKey] = file.type;
            this.fileDetailsId.titles[fieldKey] = file.name;

            this.updateFieldState(fieldKey, file.name);
        };
        reader.readAsDataURL(file);
    }

    handleSaveAndNext() {
        let hasFile = false;
        let uploadPromises = [];

        for (let field of this.idFields) {
            const fieldKey = field.key;
            const fileName = this.fileDetailsId.titles[fieldKey];
            const base64Data = this.fileDetailsId.contents[fieldKey];
            const contentType = this.fileDetailsId.types[fieldKey];

            if (fileName && base64Data && contentType) {
                hasFile = true;

                const uploadPromise = uploadFileToRecord({
                    parentId: this.selectedContactId,
                    fileName,
                    base64Data,
                    contentType
                })
                    .then(() => {
                        this.updateFieldUploadedState(fieldKey, fileName);
                        this.showSuccess('File uploaded successfully.');
                        // this.dispatchEvent(new CustomEvent('documentupload', {
                        //     bubbles: true,
                        //     composed: true
                        // }));
                    })
                    .catch(error => {
                        console.error('Upload error:', error);
                        this.showError(`${fileName} upload failed.`);
                    });
                uploadPromises.push(uploadPromise);
            }
        }

        if (hasFile) {
            Promise.all(uploadPromises).then(() => {
                this.dispatchEvent(new CustomEvent('documentuploaded', {
                    bubbles: true,
                    composed: true
                }));
            });
        }
        else if (this.isNoDocumentChecked) {
            this.dispatchEvent(new CustomEvent('documentupload', {
                bubbles: true,
                composed: true
            }));
        }

        else {
            this.showError('Please upload a document or check the "no document" box before continuing.');
        }
    }

    handleBack() {
        this.dispatchEvent(new CustomEvent('backfromdocupload', {
            bubbles: true,
            composed: true
        }));
    }

    updateFieldState(key, fileName) {
        const field = this.idFields.find(f => f.key === key);
        if (field) {
            field.currentFileName = fileName;
            field.uploaded = false;
            this.idFields = [...this.idFields];
        }
    }

    updateFieldUploadedState(key, fileName) {
        const field = this.idFields.find(f => f.key === key);
        if (field) {
            field.currentFileName = fileName;
            field.uploaded = true;
            this.idFields = [...this.idFields];
        }
    }

    removeAttachment(event) {
        const button = event.target.closest('button[data-id]');
        const fieldKey = button?.dataset?.id;
        if (!fieldKey) return;

        const field = this.idFields.find(f => f.key === fieldKey);
        if (field) {
            field.currentFileName = '';
            field.uploaded = false;

            delete this.fileDetailsId.contents[fieldKey];
            delete this.fileDetailsId.types[fieldKey];
            delete this.fileDetailsId.titles[fieldKey];

            const input = this.template.querySelector(`input[data-id="${fieldKey}"]`);
            if (input) {
                input.value = '';
            }

            this.idFields = [...this.idFields];
        }
    }

    showError(message) {
        this.dispatchEvent(new ShowToastEvent({
            title: 'Error',
            message: message,
            variant: 'error',
            mode: 'dismissable'
        }));
    }

    showSuccess(message) {
        this.dispatchEvent(new ShowToastEvent({
            title: 'Success',
            message: message,
            variant: 'success',
            mode: 'dismissable'
        }));
    }
}