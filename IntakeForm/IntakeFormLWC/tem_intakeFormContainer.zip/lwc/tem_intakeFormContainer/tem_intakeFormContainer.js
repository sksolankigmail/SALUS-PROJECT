import { LightningElement, track, wire } from 'lwc';
import getPicklistValues from '@salesforce/apex/IntakeFormController.getPicklistValues';
import saveContact from '@salesforce/apex/IntakeFormController.saveContact';
import isEmailAvailable from '@salesforce/apex/IntakeFormController.isEmailAvailable';
import isPhoneAvailable from '@salesforce/apex/IntakeFormController.isPhoneAvailable';
import isAlienAvailable from '@salesforce/apex/IntakeFormController.isAlienAvailable';
import isPassportAvailable from '@salesforce/apex/IntakeFormController.isPassportAvailable';
import tem_CBP_formicons from '@salesforce/resourceUrl/tem_CBP_formicons';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';


export default class Tem_intakeFormContainer extends LightningElement {

    uploadPhoto = tem_CBP_formicons + '/icon_upload.svg';
    forwardArrow = tem_CBP_formicons + '/icon_right_arrow.svg';
    first_icon = tem_CBP_formicons + '/first_icon.svg';
    icon_deselect_1 = tem_CBP_formicons + '/icon_deselect_1.svg';
    second_icon = tem_CBP_formicons + '/second_icon.svg';
    deselect_second = tem_CBP_formicons + '/deselect_second.svg';
    icon_checked = tem_CBP_formicons + '/icon_checked.svg';
    third_icon = tem_CBP_formicons + '/third_icon.svg';
    deselect_third = tem_CBP_formicons + '/deselect_third.svg';
    fourth_icon = tem_CBP_formicons + '/icon_four.png';
    deselect_four = tem_CBP_formicons + '/deselect_4_icon.svg';

    @track fields = {
        firstName: '',
        lastName: '',
        gender: '',
        birthdate: '',
        citizenshipCountry: '',
        destinationCountry: '',
        departureDate: '',
        prefferdLanguage: '',
        email: '',
        phone: '',
        whatsapp: '',
        travelOption: '',
        familyMemberCount: '',
        passportNumber: '',
        passportIssuingCountry: '',
        passportExpirationDate: '',
        alienNumber: '',
        address: '',
        city: '',
        stateCode: '',
        zipCode: ''
    };

    @track capturedBiometricImage = null;

    @track familyMember = false;
    generatedAccountId = '';
    generatedContactId = '';

    @track isPersonalCompleted = false;
    @track isBiometricCompleted = false;
    @track isUploadCompleted = false;
    @track isMedicalCompleted = false;

    @track personalDetails = true;
    @track showBiometrics = false;
    @track medicalDetails = false;
    @track documentUpload = false;
    @track successUpload = false;
    @track showAddMember = false;

    @track currentStep = 'personal';

    @track selectedGender;
    @track genderOptions = [];

    handleListView() {
        this.showAddMember = true;
        this.familyMember = false;

        setTimeout(() => {
            if (this.refs.target?.handleRefresh) {
                this.refs.target.handleRefresh();
            }
        }, 100);
    }

    handlePreFill() {
        this.fields.firstName = 'John';
        this.fields.lastName = 'Carter';
        this.selectedGender = 'Male';
        //this.fields.birthdate = '08/15/1990';
        this.fields.citizenshipCountry = 'Canada';
        this.fields.destinationCountry = 'United States (New York City)';
        //this.fields.departureDate = '07/01/2025';
        this.fields.prefferdLanguage = 'English';
        this.fields.email = 'john.carter90@example.com';
        this.fields.phone = '+1-202-555-0191';
        this.fields.whatsapp = '+1-202-555-0191';
        this.selectedTravelValue = 'With family/household members';
        this.fields.familyMemberCount = '3';
        this.fields.passportNumber = 'C12345678';
        this.fields.passportIssuingCountry = 'Canada';
        //this.fields.passportExpirationDate = '09/30/2030';
        this.fields.alienNumber = 'A123456789';
        this.fields.address = '1234 Elm Street';
        this.fields.city = 'Washington';
        this.fields.stateCode = 'DC';
        this.fields.zipCode = '20001';
    }

    get personalTabClass() {
        if (this.currentStep === 'personal') return 'active-tab';
        return this.isPersonalCompleted ? 'completed-tab' : 'pending-tab';
    }

    get biometricsTabClass() {
        if (this.currentStep === 'biometrics') return 'active-tab';
        return this.isBiometricCompleted ? 'completed-tab' : 'pending-tab';
    }

    get documentUploadTabClass() {
        if (this.currentStep === 'uploadDoc') return 'active-tab';
        return this.isUploadCompleted ? 'completed-tab' : 'pending-tab';
    }

    get addMemberTabClass() {
        if (this.currentStep === 'addMoremember') return 'active-tab';
        return this.isAddMemberCompleted ? 'completed-tab' : 'pending-tab';
    }

    get medicalTabClass() {
        if (this.currentStep === 'medicalCondition') return 'active-tab';
        return this.isMedicalCompleted ? 'completed-tab' : 'pending-tab';
    }



    get isCurrentStepPersonal() {
        return this.currentStep === 'personal';
    }

    get isCurrentStepBiometric() {
        return this.currentStep === 'biometrics';
    }

    get isCurrentStepUpload() {
        return this.currentStep === 'uploadDoc';
    }

    get isCurrentStepMedical() {
        return this.currentStep === 'medicalCondition';
    }

    handleGenderChange(event) {
        this.selectedGender = event.detail.value;
        console.log('Selected gender:', this.selectedGender);
    }

    handleTravelChange(event) {
        this.selectedTravelValue = event.detail.value;
        console.log('Selected selectedTravelValue:', this.selectedTravelValue);
        if (this.isTravelingAlone) {
            this.fields.familyMemberCount = '';
            this.fields = { ...this.fields };
        }
    }

    handleBack() {
        this.medicalDetails = false;
        this.personalDetails = true;
        this.showBiometrics = false;
    }

    handleNext() {
        this.showBiometrics = true;
        this.personalDetails = false;
        this.isPersonalCompleted = true;
        this.currentStep = 'biometrics';
    }

    get formattedBirthdate() {
        if (!this.fields.birthdate) return '';
        const date = new Date(this.fields.birthdate);
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        const year = date.getFullYear();
        return `${month}/${day}/${year}`;
    }

    get formattedPassportDepartureDate() {
        if (!this.fields.departureDate) return '';
        const date = new Date(this.fields.departureDate);
        if (isNaN(date)) return '';
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        const year = date.getFullYear();
        return `${month}/${day}/${year}`;
    }

    get formattedPassportExpiryDate() {
        if (!this.fields.departureDate) return '';
        const date = new Date(this.fields.departureDate);
        if (isNaN(date)) return '';
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        const year = date.getFullYear();
        return `${month}/${day}/${year}`;
    }

    @track travelOptions = [];
    @track selectedTravelValue;

    showToast(title, message, variant) {
        this.dispatchEvent(
            new ShowToastEvent({
                title: title,
                message: message,
                variant: variant
            })
        );
    }

    async handleSaveAndNext() {
        try {
            // Call the save method
            await this.handleSave();

        } catch (error) {
            console.error('Save failed:', error);
            this.showToast('Error', 'Please Fill all the mandatory details.', 'error');
        }
    }


    connectedCallback() {
        this.fetchPicklistValues('Contact', 'Gender__c', 'genderOptions');
        this.fetchPicklistValues('Case', 'Are_you_traveling_alone_or_with_others__c', 'travelOptions');
    }

    fetchPicklistValues(objectApiName, fieldApiName, stateProperty) {
        getPicklistValues({ objectApiName, fieldApiName })
            .then(data => {
                this[stateProperty] = data.map(item => ({
                    label: item.label,
                    value: item.value
                }));
                console.log(`${fieldApiName} Picklist Values:`, this[stateProperty]);
            })
            .catch(error => {
                this.showToast('Error', `Error fetching ${fieldApiName} values`, 'error');
            });
    }

    handleChange(event) {
        const field = event.target.dataset.field || event.target.name;
        const value = event.target.value;

        let finalValue = value;

        // If it's a date field in MM/DD/YYYY format, convert to ISO (YYYY-MM-DD)
        if (event.target.type === 'text' && field === 'birthdate') {
            const parts = value.split('/');
            if (parts.length === 3) {
                const [month, day, year] = parts;
                if (month.length === 2 && day.length === 2 && year.length === 4) {
                    finalValue = `${year}-${month}-${day}`;
                }
            }
        } else if (event.target.type === 'text' && field === 'departureDate') {
            const parts = value.split('/');
            if (parts.length === 3) {
                const [month, day, year] = parts;
                if (month.length === 2 && day.length === 2 && year.length === 4) {
                    finalValue = `${year}-${month}-${day}`;
                }
            }
        } else if (event.target.type === 'text' && field === 'passportExpirationDate') {
            const parts = value.split('/');
            if (parts.length === 3) {
                const [month, day, year] = parts;
                if (month.length === 2 && day.length === 2 && year.length === 4) {
                    finalValue = `${year}-${month}-${day}`;
                }
            }
        }

        this.fields[field] = finalValue;
        console.log(`Field ${field} updated: ${finalValue}`);
    }
    get isTravelingAlone() {
        return this.selectedTravelValue === 'Alone' ||
            this.selectedTravelValue === 'alone' ||
            this.selectedTravelValue === 'ALONE';
    }
    @track memberCount = '';
    @track primaryMember = '';

    async handleSave() {

        //  console.log('email' + this.fields.email + 'phone' + this.fields.phone)
        //     const isemailAvailable = await isEmailAvailable({ email:this.fields.email });
        //     if (isemailAvailable) {
        //         this.showToast('Error', 'Email Already Exist.', 'error');
        //         return; 
        //     }
        //    const isphoneAvailable = await isPhoneAvailable({ phone:this.fields.email });
        //     if (isphoneAvailable) {
        //         this.showToast('Error', 'Phone Number Already Exist.', 'error');
        //         return; 
        //     }
        //     const isalienAvailable = await isAlienAvailable({ aliennum:this.fields.alienNumber });
        //     if (isalienAvailable) {
        //         this.showToast('Error', 'Alien Number Already Exist.', 'error');
        //         return; 
        //     }
        //     const ispassportAvailable = await isPassportAvailable({ passport:this.fields.passportNumber });
        //     if (ispassportAvailable) {
        //         this.showToast('Error', 'Passport Number Already Exist.', 'error');
        //         return; 
        //     }

        const requiredFields = [
            { name: 'Email', value: this.fields.email },
            { name: 'Phone', value: this.fields.phone },
            { name: 'Alien Number', value: this.fields.alienNumber }
        ];

        for (const field of requiredFields) {
            if (!field.value || field.value.trim() === '') {
                this.showToast('Validation Error', `Please enter the correct ${field.name}.`, 'error');
                return;
            }
        }

        let isEmailDup = false;
        let isPhoneDup = false;
        let isAlienDup = false;
        let isPassportDup = false;
        /*if (!this.generatedContactId) {
                try {
                    [isEmailDup, isPhoneDup, isAlienDup, isPassportDup] = await Promise.all([
                        isEmailAvailable({ email: this.fields.email }),
                        isPhoneAvailable({ phone: this.fields.phone }),
                        isAlienAvailable({ aliennum: this.fields.alienNumber }),
                        isPassportAvailable({ passport: this.fields.passportNumber })
                    ]);
                } catch (dupError) {
                    console.error('Error checking for duplicates:', dupError);
                    this.showToast('Error', `Error validating duplicate fields: ${dupError.body?.message || dupError.message}`, 'error');
                    return;
                }

                if (isEmailDup) {
                    console.warn('Duplicate found: Email');
                    this.showToast('Duplicate Record', 'Email already exists.', 'warning');
                    return;
                }

                if (isPhoneDup) {
                    console.warn('Duplicate found: Phone');
                    this.showToast('Duplicate Record', 'Phone number already exists.', 'warning');
                    return;
                }

                if (isAlienDup) {
                    console.warn('Duplicate found: Alien Number');
                    this.showToast('Duplicate Record', 'Alien number already exists.', 'warning');
                    return;
                }

                if (isPassportDup) {
                    console.warn('Duplicate found: Passport Number');
                    this.showToast('Duplicate Record', 'Passport number already exists.', 'warning');
                    return;
                }
        }*/



        const contactData = {
            firstName: this.fields.firstName,
            lastName: this.fields.lastName,
            birthdate: this.fields.birthdate,
            gender: this.selectedGender,
            citizenshipCountry: this.fields.citizenshipCountry,
            destinationCountry: this.fields.destinationCountry,
            departureDate: this.fields.departureDate,
            prefferdLanguage: this.fields.prefferdLanguage,
            travelOption: this.fields.selectedTravelValue,
            familyMemberCount: this.fields.familyMemberCount,
            email: this.fields.email,
            phone: this.fields.phone,
            whatsapp: this.fields.whatsapp,
            passportNumber: this.fields.passportNumber,
            passportIssuingCountry: this.fields.passportIssuingCountry,
            passportExpirationDate: this.fields.passportExpirationDate,
            alienNumber: this.fields.alienNumber,
            address: this.fields.address,
            city: this.fields.city,
            stateCode: this.fields.stateCode,
            zipCode: this.fields.zipCode,
            accountId: '',
            contactId: this.contactId
        };
        this.memberCount = this.fields.familyMemberCount;
        this.primaryMember = this.fields.firstName;
        console.log('this.memberCount', JSON.stringify(this.memberCount));

        try {
            const contactDetails = await saveContact({ contactData });
            console.log('contactDetails : ', contactDetails);
            this.generatedContactId = contactDetails.Id;
            console.log('This is Contact Id' + this.generatedContactId)
            this.generatedAccountId = contactDetails.AccountId;
            this.showToast('Success', 'Contact saved successfully!', 'success');
            this.personalDetails = false;
            this.isPersonalCompleted = true;
            this.currentStep = 'biometrics';
            this.showBiometrics = true;
            console.log('stored generatedAccountId ID:', JSON.stringify(this.generatedAccountId));
        } catch (error) {
            console.error('Error saving contact:', error);

            if (error.body && error.body.message && error.body.message.includes('DUPLICATES_DETECTED')) {
                // Try guessing the field
                let possibleFields = [];
                if (this.fields.email) possibleFields.push('Email');
                if (this.fields.phone) possibleFields.push('Phone');
                if (this.fields.whatsapp) possibleFields.push('WhatsApp');
                if (this.fields.passportNumber) possibleFields.push('Passport Number');

                this.showToast(
                    'Duplicate Record',
                    `A contact with similar ${possibleFields.join(', ')} may already exist.`,
                    'warning'
                );
            } else {
                this.showToast('Error', 'Failed to save contact.', 'error');
            }
        }

    }

    // biomatric completed handler
    @track contactId = null;
    handleBiometriBack(event) {
        this.personalDetails = true;
        this.showBiometrics = false;
        this.contactId = event.detail.contactId;
        console.log('this is id returned from biomatric ' + JSON.stringify(this.contactId));

    }

    handleChildTravelDetails() {
        this.medicalDetails = true;
        this.showAddMember = false;
    }
    refreshAfterRender = false;
    handleBiometricCompleted(event) {
        this.documentUpload = true;
        this.showBiometrics = false;
        this.isBiometricCompleted = true;
       // this.refreshAfterRender = true;
        this.currentStep = 'uploadDoc';
        // setTimeout(() => {
        //     const listView = this.refs?.target;
        //     console.log('Ref to list view:', listView);

        //     if (listView && typeof listView.handleRefresh === 'function') {
        //         console.log('Calling handleRefresh...');
        //         listView.handleRefresh();
        //     } else {
        //         console.error('handleRefresh not available on listView');
        //     }
        // }, 300);
    }

    handleBackFromUpload() {
        this.documentUpload = false;
        this.showBiometrics = true;
        this.currentStep = 'biometrics';

        const biometricCmp = this.template.querySelector('c-mol_biometrics-capture');
        if (biometricCmp && this.capturedBiometricImage) {
            biometricCmp.setCapturedImage(this.capturedBiometricImage);
        }
    }

    handleAfterDocumentUpload() {
        this.showAddMember = true;
        this.documentUpload = false;
        this.isUploadCompleted = true;
        this.currentStep = 'addMoremember';
    }

    handleMedicalCompleted() {
        this.showAddMember = true;
        this.medicalDetails = false;
        this.currentStep = 'addMoremember';
    }
    handlebackClicked() {
        this.showAddMember = true;
        this.medicalDetails = false;
        //this.currentStep = 'uploadDoc';
    }

    handleAddMoreMember() {
        this.familyMember = true;
    }

    showConcentForm = false;
    handleSaveNextSuccess() {
        this.familyMember = false;
        this.showAddMember = false;
        this.isAddMemberCompleted = true;
        this.currentStep ='';
        //this.successUpload = true;

        this.showConcentForm = true;
    }
    // family member

    @track currentMemberIndex;
    @track membersAdded = 0;
    @track memberIndex;
    @track pendingIndexToMark = null;

    @track addedFamilyIndexes = [];

    handleFamilyMemberClicked(event) {
        this.currentMemberIndex = event.detail.memberIndex;
        console.log('this.currentMEmberIndex in parent', JSON.stringify(this.currentMemberIndex));
        // this.showSuccessScreen = false;
        this.familyMember = true;
    }

    handleFamilyCompleted(event) {
        console.log('this.handleFamilyCompleted');
        const index = event.detail.memberIndex;
        console.log('this.index in handleFamilyCompleted', JSON.stringify(index));
        this.familyMember = false;
        // this.successUpload = true;
        this.showAddMember = true;

        if (!this.addedFamilyIndexes.includes(index)) {
            this.addedFamilyIndexes.push(index);
        }
        console.log('this.addedFamilyIndex', JSON.stringify(this.addedFamilyIndexes));

        // Delay slightly to allow success screen to render first
        setTimeout(() => {
            const successCmp = this.template.querySelector('c-tem_intake-form-success');
            if (successCmp) {
                successCmp.markMemberAsAdded(index);
            } else {
                console.warn('Success component not found');
            }
        }, 50); // Delay lets DOM render <c-tem_intake-form-success>
    }


    handleReset() {
        this.fields = {
            firstName: '',
            lastName: '',
            birthdate: '',
            citizenshipCountry: '',
            destinationCountry: '',
            departureDate: '',
            prefferdLanguage: '',
            selectedTravelValue: '',
            familyMemberCount: '',
            email: '',
            phone: '',
            whatsapp: '',
            passportNumber: '',
            passportIssuingCountry: '',
            passportExpirationDate: '',
            alienNumber: '',
            address: '',
            city: '',
            stateCode: '',
            zipCode: ''
        };

        this.selectedGender = '';
        this.selectedTravelValue = '';
        this.contactId = '';
    }

}