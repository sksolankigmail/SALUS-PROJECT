import { LightningElement,track } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

export default class Tem_consentForm extends LightningElement {

    @track showConsent = true;
    @track acceptConsent = false;

    handledecline() {
        window.location.reload();
    }
    handleSubmit(){
        if(this.acceptConsent) {
            this.showConsent = false;
        }else {
            this.showError('Please select the consent checkbox.');
        }
        
    }

    handleConsentChange() {
        this.acceptConsent = !this.acceptConsent;
    }

    showError(message) {
        this.dispatchEvent(new ShowToastEvent({
            title: 'Error',
            message: message,
            variant: 'error',
            mode: 'dismissable'
        }));
    }
}